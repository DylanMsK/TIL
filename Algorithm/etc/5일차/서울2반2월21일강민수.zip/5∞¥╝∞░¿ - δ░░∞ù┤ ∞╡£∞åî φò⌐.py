import sys
sys.stdin = open('/Users/dylan/Desktop/github/TIL/Algorithm/etc/5일차/합_input.txt', 'r')

def find_next(x_idx, next_y, N, values):
    promissing = [True] * N

    for idx in values:
        if values:
            continue
        x_idx[idx] = (-1, -1)

    for x in range(N):
        if x_idx[x][0] != -1:
            promissing[x] = False

    # n = 0
    # for i in range(1, N+1):
    #     if in_perm[i-1] == False:
    #         c[n] = i
    #         n += 1
    return promissing


def backtrack(x_idx, y, N):
    global min_
    global arr
    # c = [0]     # 노드들의 value
    values = [0] * N
    for idx, i in enumerate(x_idx):
        if i[0] != -1:
            values[idx] = i[1]
    #     if 
    # values = []
    # values = [x_idx[x] * arr[y][x] for x in range(N)]

    if y == N-1:
        print(x_idx, values)
        if sum(values) < min_:
            min_ = sum(values)
            print(sum(values))
        # sum이 들어올 곳
        # sum < minvalue: minvalue = sum 업데이트
        # for i in range(1, y+1):
        #     print(c)
    else:
        y += 1
        # 다음 자식 노드를 찾음
        promissing = find_next(x_idx, y, N, values)
        # 자식 노드를 돌면서

        for idx, nxt_x in enumerate(promissing):
            # 다음 자식 노드들을 데리고 backtracking을 이어서 함 - sum이 계속 누적되어서 가야함
            if nxt_x:
                if sum(values) + arr[y][idx] >= min_:
                    return
                else:
                    x_idx[idx] = (idx, arr[y][idx])
                    backtrack(x_idx, y, N)


for _ in range(int(input())):
    N = int(input())
    arr = [list(map(int, input().split())) for i in range(N)]
    min_ = 100
    # first_x = [1] + [0] * (N-1)
    for i in range(N):
        first_x = [(i, arr[k][i]) if k == 0 else (-1, -1) for k in range(N)]
        backtrack(first_x, 0, N)
    break


